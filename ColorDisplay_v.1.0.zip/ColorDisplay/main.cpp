#include <iostream>
#include <conio.h>
#include "ColorDisplay.h"

using namespace std;

int main()
{
    ColorDisplay cd( 60 , 20 , {1,4} );
    ColorCharacter cc;
    COORD pos;

//    while (!kbhit())
//    {
//        pos.X = (short) (rand() % 20);
//        pos.Y = (short) (rand() % 20);
//        if (rand() % 2 == 1)
//            cc.color = (unsigned char) 7;
//        else
//            cc.color = (unsigned char) 8;
//        cd.setColorCharacterAtPosition(cc, pos);
//    }

    cc.character = 219; cc.color = RED;

    cc.color = RED;
    Image tShape(2,3); tShape.image[0][1] = tShape.image[1][0] = tShape.image[1][1] = tShape.image[1][2] = cc;
    cc.color = GREEN;
    Image lShape(3,2); lShape.image[0][0] = lShape.image[1][0] = lShape.image[2][0] = lShape.image[2][1] = cc;
    cc.color = YELLOW;
    Image iShape(1,4); iShape.image[0][0] = iShape.image[0][1] = iShape.image[0][2] = iShape.image[0][3] = cc;
    cc.color = PURPLE;
    Image sShape(2,2); sShape.image[0][0] = sShape.image[0][1] = sShape.image[1][0] = sShape.image[1][1] = cc;
    cc.color = WHITE;
    Image zShape(2,3); zShape.image[0][0] = zShape.image[0][1] = zShape.image[1][1] = zShape.image[1][2] = cc;

    while (true) {
        cd.resetDisplay();

        pos = { 40 , 0 };
        cd.displayImage(lShape, pos);

        pos = { 40 , 4 };
        cd.displayImage(tShape, pos);

        pos = { 40 , 7 };
        cd.displayImage(sShape, pos);

        pos = { 40 , 10 };
        cd.displayImage(zShape, pos);

        pos = { 40 , 13 };
        cd.displayImage(iShape, pos);

        while (!kbhit())
        {
        }
        getch();

        cd.resetDisplay();

        pos = { 10 , 10 };
        cd.displayImage(lShape, pos);

        pos = { 12 , 11 };
        cd.displayImage(tShape, pos);

        pos = { 11 , 10 };
        cd.displayImage(sShape, pos);

        pos = { 14 , 11 };
        cd.displayImage(iShape, pos);

        pos = { 17 , 10 };
        cd.displayImage(zShape, pos);

        while (!kbhit())
        {
        }
        getch();
    }

    return 0;
}
