Color Display version 1.0
Image constructed by n times m matrix of ColorCharacters. Empty region indicated by { BLACK , ' ' }
ColorDisplay display Image by scanning the whole n times m matrix