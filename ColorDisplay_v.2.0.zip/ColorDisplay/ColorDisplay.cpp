#include "ColorDisplay.h"

#include <iostream>

ColorDisplay::ColorDisplay( short _xScreeSize , short _yScreenSize , COORD _origin )
{
    outConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    origin = _origin;
    xScreenSize = _xScreeSize;
    yScreenSize = _yScreenSize;
}

void ColorDisplay::setColorCharacterAtPosition( const ColorCharacter & colorchar , const COORD & positionition)
{
    DWORD garbage = 0;
    FillConsoleOutputCharacter(outConsole, colorchar.character, 1, positionition, &garbage);
    FillConsoleOutputAttribute(outConsole, colorchar.color, 1, positionition, &garbage);
}

void ColorDisplay::setColorCharacterAtPosition( const ColorCharacter & colorchar , short xPosition , short yPosition )
{
    COORD positionition = { xPosition , yPosition };
    setColorCharacterAtPosition(colorchar, positionition);
}

void ColorDisplay::resetDisplay()
{
    DWORD garbage = 0;
    COORD position;
    ColorCharacter cc; cc.color = BRIGHT_WHITE;

    position.X = origin.X; position.Y = origin.Y - 1; cc.character = 196;
    FillConsoleOutputCharacter(outConsole, cc.character, xScreenSize, position, &garbage);
    FillConsoleOutputAttribute(outConsole, cc.color, xScreenSize, position, &garbage);

    position.X = origin.X - 1; position.Y = origin.Y - 1; cc.character = 218;
    setColorCharacterAtPosition(cc, position);

    position.X = origin.X + xScreenSize; position.Y = origin.Y - 1; cc.character = 191;
    setColorCharacterAtPosition(cc, position);

    position.X = origin.X; position.Y = origin.Y + yScreenSize; cc.character = 196;
    FillConsoleOutputCharacter(outConsole, cc.character, xScreenSize, position, &garbage);
    FillConsoleOutputAttribute(outConsole, cc.color, xScreenSize, position, &garbage);

    position.X = origin.X - 1; position.Y = origin.Y + yScreenSize; cc.character = 192;
    setColorCharacterAtPosition(cc, position);

    position.X = origin.X + xScreenSize; position.Y = origin.Y + yScreenSize; cc.character = 217;
    setColorCharacterAtPosition(cc, position);

    cc.character = 179;
    short yPosScreen = yScreenSize + origin.Y;
    for (position.Y = origin.Y; position.Y < yPosScreen; position.Y++)
    {
        position.X = origin.X - 1;
        setColorCharacterAtPosition(cc, position);
        position.X = origin.X + xScreenSize;
        setColorCharacterAtPosition(cc, position);
    }
    position.X = origin.X; cc.character = ' '; cc.color = BLUE * 16;
    for (position.Y = origin.Y; position.Y < yPosScreen; position.Y++)
    {
        FillConsoleOutputCharacter(outConsole, cc.character, xScreenSize, position, &garbage);
        FillConsoleOutputAttribute(outConsole, cc.color, xScreenSize, position, &garbage);
    }
}

void ColorDisplay::displayImage( const Image & img )
{
    COORD pos;
    for (unsigned short i = 0; i < img.shape.size(); i++)
    {
        pos.X = img.shape[i].coordinate.X + img.position.X + origin.X;
        pos.Y = img.shape[i].coordinate.Y + img.position.Y + origin.Y;
        setColorCharacterAtPosition(img.shape[i].colorcharacter, pos);
    }

}
