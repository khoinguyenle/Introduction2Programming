Color Display version 2.0
Image constructed by vector of PixelConsole and its actual position 
PixelConsole constructed by ColorCharacter & coordinate of this character.
ColorDisplay display Image by scanning the whole vector of PixelConsole and place them on the relative position