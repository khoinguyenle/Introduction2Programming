#include <iostream>
#include <conio.h>
#include "ColorDisplay.h"

using namespace std;

int main()
{
    ColorDisplay cd( 60 , 20 , {1,4} );
    ColorCharacter cc = { BLACK , 176 };
    COORD pos;

    while (!kbhit())
    {
        pos.X = (short) (rand() % 20);
        pos.Y = (short) (rand() % 20);
        if (rand() % 2 == 1)
            cc.color = (unsigned char) 7;
        else
            cc.color = (unsigned char) 8;
        //cc.color = (short) (rand() % 16);
        cd.setColorCharacterAtPosition(cc, pos);
    }

//    cc.character = 219; cc.color = RED;
//
//    cc.color = RED;
//    Image tShape(4);
//    tShape.shape.push_back({cc, {1,0}});
//    tShape.shape.push_back({cc, {0,1}});
//    tShape.shape.push_back({cc, {1,1}});
//    tShape.shape.push_back({cc, {2,1}});
//
//    cc.color = GREEN;
//    Image lShape(4);
//    lShape.shape.push_back({cc, {0,0}});
//    lShape.shape.push_back({cc, {0,1}});
//    lShape.shape.push_back({cc, {0,2}});
//    lShape.shape.push_back({cc, {1,2}});
//
//    cc.color = YELLOW;
//    Image iShape(4);
//    iShape.shape.push_back({cc, {0,0}});
//    iShape.shape.push_back({cc, {1,0}});
//    iShape.shape.push_back({cc, {2,0}});
//    iShape.shape.push_back({cc, {3,0}});
//
//    cc.color = PURPLE;
//    Image sShape(4);
//    sShape.shape.push_back({cc, {0,0}});
//    sShape.shape.push_back({cc, {0,1}});
//    sShape.shape.push_back({cc, {1,0}});
//    sShape.shape.push_back({cc, {1,1}});
//
//    cc.color = WHITE;
//    Image zShape(4);
//    zShape.shape.push_back({cc, {0,0}});
//    zShape.shape.push_back({cc, {1,0}});
//    zShape.shape.push_back({cc, {1,1}});
//    zShape.shape.push_back({cc, {2,1}});
//
//    while (true) {
//        cd.resetDisplay();
//
//        lShape.position = { 40 , 0 };
//        cd.displayImage(lShape);
//
//        tShape.position = { 40 , 4 };
//        cd.displayImage(tShape);
//
//        sShape.position = { 40 , 7 };
//        cd.displayImage(sShape);
//
//        zShape.position = { 40 , 10 };
//        cd.displayImage(zShape);
//
//        iShape.position = { 40 , 13 };
//        cd.displayImage(iShape);
//
////        while (!kbhit())
////        {
////        }
////        getch();
//
//        cd.resetDisplay();
//
//        lShape.position = { 10 , 10 };
//        cd.displayImage(lShape);
//
//        tShape.position = { 12 , 11 };
//        cd.displayImage(tShape);
//
//        sShape.position = { 11 , 10 };
//        cd.displayImage(sShape);
//
//        zShape.position = { 17 , 10 };
//        cd.displayImage(zShape);
//
//        iShape.position = { 14 , 11 };
//        cd.displayImage(iShape);
//
////        while (!kbhit())
////        {
////        }
////        getch();
//    }

    return 0;
}
